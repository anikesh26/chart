import { Injectable } from '@angular/core';
import * as Highcharts from 'highcharts';
import {chartOptions} from './chartoptions.interface'
@Injectable({
  providedIn: 'root'
})
export class NewchartService {
myOptions
  constructor() { }
  createChart(el, cfg) {
    this.myOptions = {
      chart: {
         type: 'column'
      },
      title: {
         text: ''
      },
      xAxis: {
         categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
      },
      yAxis: {
         allowDecimals: false,
         min: 0,
         title: {
            text: ''
         }
      },
      plotOptions: {
         column: {
            stacking: 'normal'
         }
      },
      credits: {
         enabled: false
      },
      legend: {
         legendTitle: 'Campaigns',
         layout: 'vertical',
         align: 'right',
         verticalAlign: 'top',
         floating: false,
         borderWidth: 1,
         backgroundColor: ((Highcharts.theme && Highcharts.theme.colors) || '#FFFFFF'),
         shadow: true
      },
   
      series: cfg
   };
    Highcharts.chart(el, this.myOptions);
  }
}
