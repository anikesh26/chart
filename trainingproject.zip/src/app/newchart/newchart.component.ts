import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as Highcharts from 'highcharts';
import { NewchartService } from './newchart.service';
@Component({
  selector: 'app-newchart',
  templateUrl: './newchart.component.html',
  styleUrls: ['./newchart.component.css']
})
export class NewchartComponent implements OnInit {
  @ViewChild("charts") charts: ElementRef;
  constructor(private highcharts: NewchartService) { }
  highchart = Highcharts;

  myOptions = {
    chart: {
       type: 'column'
    },
    title: {
       text: ''
    },
    xAxis: {
       categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
    },
    yAxis: {
       allowDecimals: false,
       min: 0,
       title: {
          text: ''
       }
    },
    plotOptions: {
       column: {
          stacking: 'normal'
       }
    },
    credits: {
       enabled: false
    },
    legend: {
       legendTitle: 'Campaigns',
       layout: 'vertical',
       align: 'right',
       verticalAlign: 'top',
       floating: false,
       borderWidth: 1,
       backgroundColor: ((Highcharts.theme && Highcharts.theme.colors) || '#FFFFFF'),
       shadow: true
    },
 
    series: [
      {
        name: "Campaign 1",
        data: [5, 3, 4, 7, 2],
        stack: "hours"
      },
      {
        name: "Campaign 2",
        data: [2, 2, 3, 2, 1],
        stack: "hours"
      },
      {
        name: "Campaign 3",
        data: [3, 4, 4, 2, 5],
        stack: "hours"
      },
      {
        linkedTo: "Campaign 1",
        data: [3, 4, 4, 2, 5],
        stack: "email"

      }, {
        linkedTo: "Campaign 3",
        data: [3, 4, 4, 2, 5],
        stack: "calls"
      }
    ]
 };
  chartOptions =  [
      {
        name: "Campaign 1",
        data: [5, 3, 4, 7, 2],
        stack: "hours"
      },
      {
        name: "Campaign 2",
        data: [2, 2, 3, 2, 1],
        stack: "hours"
      },
      {
        name: "Campaign 3",
        data: [3, 4, 4, 2, 5],
        stack: "hours"
      },
      {
        linkedTo: "Campaign 1",
        data: [3, 4, 4, 2, 5],
        stack: "email"

      }, {
        linkedTo: "Campaign 3",
        data: [3, 4, 4, 2, 5],
        stack: "calls"
      }
    ]


  ngOnInit(): void {

    this.highcharts.createChart(this.charts.nativeElement, this.myOptions);
  }


  onChartChanges(flag) {
    if (flag === true) {
      // console.log(flag)
      // this.highcharts.update
     const chartOptions = [
        {
          name: "John",
          data: [2, 5, 6, 3, 1],
          stack: "male"
        },
        {
          name: "Jane",
          data: [1, 5, 8, 3, 2],
          stack: "male"

        },
        {
          name: "Joe",
          data: [3, 4, 4, 2, 5],
          stack: "female"

        }
      ]

      this.highcharts.createChart(this.charts.nativeElement, chartOptions);
    } else {
      // console.log(flag)

      const chartOptions= [
        {
          name: "John",
          data: [5, 3, 0, 0, 2],
          stack: "male"
        },
        {
          name: "Jane",
          data: [2, 2, 0, 0, 1],
          stack: "transgender"
        },
        {
          name: "Joe",
          data: [3, 4, 0, 2, 5],
          stack: "female"
        }
      ];
      this.highcharts.createChart(this.charts.nativeElement, chartOptions);
    }
  }




}
