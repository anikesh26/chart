import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';

interface seriesObject {
  name: string;
  type: any;
  data: number[];
  stack: string;
}
interface IData {
  data: number[]
}
@Component({
  selector: 'app-agenteach',
  templateUrl: './agenteach.component.html',
  styleUrls: ['./agenteach.component.css']
})
export class AgenteachComponent implements OnInit {

  constructor() { }
  last7days: boolean = true;
  lastweek: boolean = false;
  Today: boolean = true;
  last4week: boolean = false;
  lastmonth: boolean = false;
  Sincestart: boolean = false;
  hourcheck: boolean = true;
  highchart: typeof Highcharts = Highcharts;
  updateFlag: boolean = false;
  update: boolean = false;
  counter: number = 0;
  dataArray: IData[] = [
    { data: [5, 3, 1] },
    { data: [2, 2, 2] },
    { data: [3, 4, 3] },
    { data: [1, 5, 4] },
    { data: [3, 4, 5] },
    { data: [7, 9, 6] },
    { data: [5, 3, 7] },
    { data: [2, 2, 8] },
    { data: [3, 4, 9] },
    { data: [1, 5, 8] },
    { data: [3, 4, 7] },
    { data: [7, 9, 6] },
    { data: [5, 3, 5] },
    { data: [2, 2, 4] },
    { data: [3, 4, 3] },
    { data: [1, 5, 2] },
    { data: [3, 4, 1] },
    { data: [7, 9, 3] },
    { data: [5, 3, 5] },
    { data: [2, 2, 6] },
    { data: [5, 6, 7] },
    { data: [4, 5, 9] },
    { data: [2, 3, 4] },
    { data: [1, 2, 6] },
  ];
  stackCheckedArray: boolean[] = [false, false, false, false, false, false, false, false];
  series: seriesObject[] = <seriesObject[]><unknown>[
    {
      name: "Campaign 1",
      id: "Campaign 1",
      type: "column",
      data: this.dataArray[0].data,
      stack: "hours",
      color: "blue",
      agent: ["agent 1", "agent 3"]
    },
    {
      name: "Campaign 2",
      id: "Campaign 2",
      type: "column",
      data: this.dataArray[1].data,
      stack: "hours",
      color: "black",
      agent: "agent 2"
    },
    {
      name: "Campaign 3",
      id: "Campaign 3",
      type: "column",
      data: this.dataArray[2].data,
      stack: "hours",
      color: "green"
    },
    {
      linkedTo: "Campaign 1",
      name: "Campaign 1",
      type: "column",
      data: this.dataArray[3].data,
      stack: "email",
      color: "blue"
    }, {
      linkedTo: "Campaign 2",
      name: "Campaign 2",
      type: "column",
      data: this.dataArray[4].data,
      stack: "email",
      color: "black"
    },
    {
      linkedTo: "Campaign 3",
      name: "Campaign 3",
      type: "column",
      data: this.dataArray[5].data,
      stack: "email",
      color: "green"
    },
    {
      linkedTo: "Campaign 1",
      name: "Campaign 1",
      type: "column",
      data: this.dataArray[6].data,
      stack: "calls",
      color: "blue"
    }, {
      linkedTo: "Campaign 2",
      name: "Campaign 2",
      type: "column",
      data: this.dataArray[7].data,
      stack: "calls",
      color: "black"
    },
    {
      linkedTo: "Campaign 3",
      name: "Campaign 3",
      type: "column",
      data: this.dataArray[8].data,
      stack: "calls",
      color: "green"
    },
    {
      linkedTo: "Campaign 1",
      name: "Campaign 1",
      type: "column",
      data: this.dataArray[9].data,
      stack: "unique",
      color: "blue"
    }, {
      linkedTo: "Campaign 2",
      name: "Campaign 2",
      type: "column",
      data: this.dataArray[10].data,
      stack: "unique",
      color: "black"
    },
    {
      linkedTo: "Campaign 3",
      name: "Campaign 3",
      type: "column",
      data: this.dataArray[11].data,
      stack: "unique",
      color: "green"
    },
    {
      linkedTo: "Campaign 1",
      name: "Campaign 1",
      type: "column",
      data: this.dataArray[12].data,
      stack: "pipeline",
      color: "blue"
    }, {
      linkedTo: "Campaign 2",
      name: "Campaign 2",
      type: "column",
      data: this.dataArray[13].data,
      stack: "pipeline",
      color: "black"
    },
    {
      linkedTo: "Campaign 3",
      name: "Campaign 3",
      type: "column",
      data: this.dataArray[14].data,
      stack: "pipeline",
      color: "green"
    },
    {
      linkedTo: "Campaign 1",
      name: "Campaign 1",
      type: "column",
      data: this.dataArray[15].data,
      stack: "lead",
      color: "blue"
    }, {
      linkedTo: "Campaign 2",
      name: "Campaign 2",
      type: "column",
      data: this.dataArray[16].data,
      stack: "lead",
      color: "black"
    },
    {
      linkedTo: "Campaign 3",
      name: "Campaign 3",
      type: "column",
      data: this.dataArray[17].data,
      stack: "lead",
      color: "green"
    },
    {
      linkedTo: "Campaign 1",
      name: "Campaign 1",
      type: "column",
      data: this.dataArray[18].data,
      stack: "conversions",
      color: "blue"
    }, {
      linkedTo: "Campaign 2",
      name: "Campaign 2",
      type: "column",
      data: this.dataArray[19].data,
      stack: "conversions",
      color: "black"
    },
    {
      linkedTo: "Campaign 3",
      name: "Campaign 3",
      type: "column",
      data: this.dataArray[20].data,
      stack: "conversions",
      color: "green"
    },
    {
      linkedTo: "Campaign 1",
      name: "Campaign 1",
      type: "column",
      data: this.dataArray[21].data,
      stack: "positive",
      color: "blue"
    }, {
      linkedTo: "Campaign 2",
      name: "Campaign 2",
      type: "column",
      data: this.dataArray[22].data,
      stack: "positive",
      color: "black"
    },
    {
      linkedTo: "Campaign 3",
      name: "Campaign 3",
      type: "column",
      data: this.dataArray[23].data,
      stack: "positive",
      color: "green"
    },

  ];


  myOptions: Highcharts.Options = {
    chart: {
      type: 'column'
    },
    title: {
      text: ''
    },
    xAxis: {
      // type:"",
      categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
    },
    yAxis: {
      allowDecimals: false,
      min: 0,
      title: {
        text: ''
      }
    },
    plotOptions: {
      column: {
        stacking: 'normal',
        colorByPoint: false
      }
    },
    credits: {
      enabled: false
    },
    legend: {
      // legendTitle: 'Campaigns',
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'top',
      floating: false,
      borderWidth: 1,
      // backgroundcolor: ((Highcharts.theme && Highcharts.theme.color) || '#FFFFFF'),
      shadow: true
    },

    series: this.series

  };



  ngOnInit(): void { 

    this.HourCheck();
  }
  HourCheck() {
    if(this.hourcheck === true) {
     this.stackCheckedArray[0] = true;

     this.dataArray[0].data = [5, 7, 1];
     this.dataArray[1].data = [2, 3, 4];
     this.dataArray[2].data = [4, 6, 6];
     this.changeDataByStackCheck();
     this.changeSeriesByDataArray(this.dataArray);
     this.update = true;
     this.counter++;

    }
    else {
     // console.log('hour unchecked');
     this.stackCheckedArray[0] = false;
     this.dataArray[0].data = [5, 7, 1];
     this.dataArray[1].data = [2, 3, 4];
     this.dataArray[2].data = [4, 6, 6];
     this.changeDataByStackCheck();

     this.changeSeriesByDataArray(this.dataArray);
     this.update = true;

     this.counter--;
   }
  }
  changeDataByStackCheck() {
    let index = 0;
    for (let i = 0; i < this.stackCheckedArray.length; i++) {
      if (this.stackCheckedArray[i] === false) {
        this.dataArray[i + index].data = [0, 0];
        this.dataArray[i + index + 1].data = [0, 0];
        this.dataArray[i + index + 2].data = [0, 0];
      }
      index += 2;
    }
  }
  changeSeriesByDataArray(dataArray: IData[]) {
    for (let i = 0; i < dataArray.length; i++) {
      this.series[i].data = dataArray[i].data;
    }
  }
  onStackClick($event) {
    this.updateFlag = !this.updateFlag;
    if ($event.target.id !== '') {

      this.changeSeriesByDataArray(this.dataArray);
      console.log($event.target.id);
      switch ($event.target.id) {
        case '5hours': {
          if ($event.target.checked === true) {
            // console.log('hour checked');
            // console.log(this.series);
            // console.log(this.dataArray);
            this.stackCheckedArray[0] = true;

            this.dataArray[0].data = [5, 7, 2];
            this.dataArray[1].data = [2, 3, 4];
            this.dataArray[2].data = [4, 6, 6];
            this.changeDataByStackCheck();
            this.changeSeriesByDataArray(this.dataArray);
            this.update = true;
            // console.log(this.series);
            // console.log(this.stackCheckedArray);

            this.counter++;
          }
          else {
            // console.log('hour unchecked');
            this.stackCheckedArray[0] = false;

            this.changeDataByStackCheck();

            this.changeSeriesByDataArray(this.dataArray);
            this.update = true;

            this.counter--;
          }
          break;
        }
        case '30emails': {
          if ($event.target.checked === true) {
            // console.log('email checked');
            this.stackCheckedArray[1] = true;

            this.dataArray[3].data = [5, 7, 7];
            this.dataArray[4].data = [5, 8, 9];
            this.dataArray[5].data = [4, 6, 8];
            this.changeDataByStackCheck();

            this.update = true;
            this.changeSeriesByDataArray(this.dataArray);

            this.counter++;
          }
          else {
            // console.log('email unchecked');
            this.stackCheckedArray[1] = false;

            this.changeDataByStackCheck();

            this.update = true;

            this.changeSeriesByDataArray(this.dataArray);

            this.counter--;
          }
          break;
        }
        case '15calls': {
          if ($event.target.checked === true) {
            // console.log('email checked');
            this.stackCheckedArray[2] = true;

            this.dataArray[6].data = [5, 7, 3];
            this.dataArray[7].data = [5, 8, 5];
            this.dataArray[8].data = [4, 6, 7];
            this.changeDataByStackCheck();

            this.update = true;
            this.changeSeriesByDataArray(this.dataArray);

            this.counter++;
          }
          else {
            // console.log('email unchecked');
            this.stackCheckedArray[2] = false;

            this.changeDataByStackCheck();

            this.update = true;

            this.changeSeriesByDataArray(this.dataArray);

            this.counter--;
          }
          break;
        }
        case '8unique': {
          if ($event.target.checked === true) {
            // console.log('email checked');
            this.stackCheckedArray[3] = true;

            this.dataArray[9].data = [5, 7, 4];
            this.dataArray[10].data = [5, 8, 5];
            this.dataArray[11].data = [4, 6, 8];
            this.changeDataByStackCheck();

            this.update = true;
            this.changeSeriesByDataArray(this.dataArray);

            this.counter++;
          }
          else {
            // console.log('email unchecked');
            this.stackCheckedArray[3] = false;

            this.changeDataByStackCheck();

            this.update = true;

            this.changeSeriesByDataArray(this.dataArray);

            this.counter--;
          }
          break;
        }
        case '5pipeline': {
          if ($event.target.checked === true) {
            // console.log('email checked');
            this.stackCheckedArray[4] = true;

            this.dataArray[12].data = [5, 7, 2];
            this.dataArray[13].data = [5, 8, 4];
            this.dataArray[14].data = [4, 6, 6];
            this.changeDataByStackCheck();

            this.update = true;
            this.changeSeriesByDataArray(this.dataArray);

            this.counter++;
          }
          else {
            console.log('email unchecked');
            this.stackCheckedArray[4] = false;

            this.changeDataByStackCheck();

            this.update = true;

            this.changeSeriesByDataArray(this.dataArray);

            this.counter--;
          }
          break;
        }
        case '10lead': {
          if ($event.target.checked === true) {
            // console.log('email checked');
            this.stackCheckedArray[5] = true;

            this.dataArray[15].data = [5, 7, 3];
            this.dataArray[16].data = [5, 8, 5];
            this.dataArray[17].data = [4, 6, 7];
            this.changeDataByStackCheck();

            this.update = true;
            this.changeSeriesByDataArray(this.dataArray);

            this.counter++;
          }
          else {
            // console.log('email unchecked');
            this.stackCheckedArray[5] = false;

            this.changeDataByStackCheck();

            this.update = true;

            this.changeSeriesByDataArray(this.dataArray);

            this.counter--;
          }
          break;
        }
        case '15conversions': {
          if ($event.target.checked === true) {
            // console.log('email checked');
            this.stackCheckedArray[6] = true;

            this.dataArray[18].data = [5, 7, 6];
            this.dataArray[19].data = [5, 8, 7];
            this.dataArray[20].data = [4, 6, 9];
            this.changeDataByStackCheck();

            this.update = true;
            this.changeSeriesByDataArray(this.dataArray);

            this.counter++;
          }
          else {
            // console.log('email unchecked');
            this.stackCheckedArray[6] = false;

            this.changeDataByStackCheck();

            this.update = true;

            this.changeSeriesByDataArray(this.dataArray);

            this.counter--;
          }
          break;
        }
        case '12positive': {
          if ($event.target.checked === true) {
            // console.log('email checked');
            this.stackCheckedArray[7] = true;

            this.dataArray[21].data = [5, 7, 1];
            this.dataArray[22].data = [5, 8, 2];
            this.dataArray[23].data = [4, 6, 4];
            this.changeDataByStackCheck();

            this.update = true;
            this.changeSeriesByDataArray(this.dataArray);

            this.counter++;
          }
          else {
            // console.log('email unchecked');
            this.stackCheckedArray[7] = false;

            this.changeDataByStackCheck();

            this.update = true;

            this.changeSeriesByDataArray(this.dataArray);

            this.counter--;
          }
          break;
        }
      }
    }

    if (this.counter === 0) {

      this.dataArray = [
        { data: [5, 3, 1] },
        { data: [2, 2, 2] },
        { data: [3, 4, 3] },
        { data: [1, 5, 4] },
        { data: [3, 4, 5] },
        { data: [7, 9, 6] },
        { data: [5, 3, 7] },
        { data: [2, 2, 8] },
        { data: [3, 4, 9] },
        { data: [1, 5, 8] },
        { data: [3, 4, 7] },
        { data: [7, 9, 6] },
        { data: [5, 3, 5] },
        { data: [2, 2, 4] },
        { data: [3, 4, 3] },
        { data: [1, 5, 2] },
        { data: [3, 4, 1] },
        { data: [7, 9, 3] },
        { data: [5, 3, 5] },
        { data: [2, 2, 6] },
        { data: [5, 6, 7] },
        { data: [4, 5, 9] },
        { data: [2, 3, 4] },
        { data: [1, 2, 6] },
      ];
      this.changeSeriesByDataArray(this.dataArray);
      this.update = true;

    }
  }
  Last7Days() {
    this.last7days = true;
    this.lastweek = false;
    this.Today = false;
    this.lastmonth = false;
    this.Sincestart = false;
    this.last4week = false;
    this.myOptions = {
      chart: {
        type: 'column'
      },
      title: {
        text: ''
      },
      xAxis: {
        categories: ['03-01-2021', '02-01-2021', '01-01-2021', '31-12-2020', '30-12-2020', '29-12-2020', '28-12-2020']
      },
      yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
          text: ''
        }
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          colorByPoint: false
        }
      },
      credits: {
        enabled: false
      },
      legend: {
        // legendTitle: 'Campaigns',
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        floating: false,
        borderWidth: 1,
        // backgroundcolor: ((Highcharts.theme && Highcharts.theme.color) || '#FFFFFF'),
        shadow: true
      },

      series: this.series

    };
  }

  lastWeek() {
    this.lastweek = true;
    this.last7days = false;
    this.Today = false;
    this.lastmonth = false;
    this.Sincestart = false;
    this.last4week = false;
    this.myOptions = {
      chart: {
        type: 'column'
      },
      title: {
        text: ''
      },
      xAxis: {
        categories: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
      },
      yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
          text: ''
        }
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          colorByPoint: false
        }
      },
      credits: {
        enabled: false
      },
      legend: {
        // legendTitle: 'Campaigns',
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        floating: false,
        borderWidth: 1,
        // backgroundcolor: ((Highcharts.theme && Highcharts.theme.color) || '#FFFFFF'),
        shadow: true
      },

      series: this.series

    };
  }

  last4Week() {
    this.last7days = false;
    this.lastweek = false;
    this.Today = false;
    this.lastmonth = false;
    this.Sincestart = false;
    this.last4week = true;
    this.myOptions = {
      chart: {
        type: 'column'
      },
      title: {
        text: ''
      },
      xAxis: {
        categories: ['28/12/20 - 03/01/21', '21/12/20 - 27/12/20', '14/12/20 - 20/12/20', '07/12/20 - 13/12/20']

      },
      yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
          text: ''
        }
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          colorByPoint: false
        }
      },
      credits: {
        enabled: false
      },
      legend: {
        // legendTitle: 'Campaigns',
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        floating: false,
        borderWidth: 1,
        // backgroundcolor: ((Highcharts.theme && Highcharts.theme.color) || '#FFFFFF'),
        shadow: true
      },

      series: this.series

    };
  }
  lastMonth() {
    this.last7days = false;
    this.lastweek = false;
    this.last4week = false;
    this.Sincestart = false;
    this.Today = false;

    this.lastmonth = true;
    this.myOptions = {
      chart: {
        type: 'column'
      },
      title: {
        text: ''
      },
      xAxis: {
        categories: ['01/12/20 - 31/12/20', '01/11/20 - 30/11/20', '01/10/20 - 31/10/20', '01/09/20 - 30/09/20']
      },
      yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
          text: ''
        }
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          colorByPoint: false
        }
      },
      credits: {
        enabled: false
      },
      legend: {
        // legendTitle: 'Campaigns',
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        floating: false,
        borderWidth: 1,
        // backgroundcolor: ((Highcharts.theme && Highcharts.theme.color) || '#FFFFFF'),
        shadow: true
      },

      series: this.series

    };
  }

  sinceStart() {
    this.last7days = false;
    this.lastweek = false;
    this.last4week = false;
    this.lastmonth = false;
    this.Today = false;

    this.Sincestart = true;
    this.myOptions = {
      chart: {
        type: 'column'
      },
      title: {
        text: ''
      },
      xAxis: {
        categories: ['Monday - Sunday', 'Monday - Sunday', 'Monday - Sunday', 'Monday - Sunday']
      },
      yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
          text: ''
        }
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          colorByPoint: false
        }
      },
      credits: {
        enabled: false
      },
      legend: {
        // legendTitle: 'Campaigns',
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        floating: false,
        borderWidth: 1,
        // backgroundcolor: ((Highcharts.theme && Highcharts.theme.color) || '#FFFFFF'),
        shadow: true
      },

      series: this.series

    };
  }
}
