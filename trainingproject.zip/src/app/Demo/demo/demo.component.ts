import { Component, OnInit } from '@angular/core';
// import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';
import { HttpClient } from "@angular/common/http";
// import Mention from '@ckeditor/ckeditor5-mention/src/mention';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic/build/ckeditor';
import { ChangeEvent } from '@ckeditor/ckeditor5-angular';
import { AllapiService } from 'src/app/allapi.service';
import {DomSanitizer} from "@angular/platform-browser";


@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  private apiUrl: string = "api/names.json"
  data: any;
  public outputString: any;
  public Editor = ClassicEditor;
  items: string[];
  editordata: any = '';
  convertData: any;
  // CKEDITOR.config.mentions = [ { feed: ['Anna', 'Thomas', 'John'], minChars: 0 } ];
  mentionConfig = {
    mentions: [
      {
        items: ["Noah", "Liam", "Mason", "Jacob"],
        triggerChar: '@'
      },
      {
        items: ["Red", "Yellow", "Green"],
        triggerChar: '#'
      },
    ]
  }
  allnames: Object;
  maincontent: any;


  constructor(private httpClient: HttpClient, private service: AllapiService) {
   }


  ngOnInit(): void {

    // this.httpClient.get(this.apiUrl).subscribe(res => {
    //   console.log(res);
    //   this.data = res;
    //   this.items = res['namesemp'];
    // });
    this.service.getEmpnames().subscribe(res => {
      console.log(res);
      this.allnames = res;
    })


  }
  public onChange({ editor }: ChangeEvent) {
    this.editordata = editor.getData();

    console.log(this.editordata);
  }

  getData() {
    this.service.getEmpnames().subscribe(res => {
      console.log(res);
      this.allnames = res;
    })

  }
  onclick(event) {

    console.log(event);
    this.service.getEmpdatabyId(event).subscribe(res => {
      console.log(res);
      this.data = res;
      this.getData();
      this.ngOnInit();
    })
  }


  onSubmit() {
    console.log(this.editordata);
    // var parser = new DOMParser();
    var editdata = this.editordata;
    const strippedString = editdata.replace(/(<([^>]+)>)/gi, "");
    console.log(strippedString);
    var mySubString = editdata.substring(
      this.editordata.lastIndexOf("@") + 1, 
      this.editordata.lastIndexOf(",")
  );
    console.log(mySubString);
    var anotherString = editdata.substring(
      this.editordata.lastIndexOf("#") + 1, 
      this.editordata.lastIndexOf("</p>")
  );
  console.log(anotherString);
  var str = this.editordata;
  var res = str.split("<p>");
  console.log(res);
  var content = res[2];
  var mainString = content.replace(/(<([^>]+)>)/gi, "");
  console.log(mainString);
  this.maincontent = mainString;

  var str = this.editordata;
  var first = str.split(" ");
  console.log(first);
  
    // this.service.addEmpnames(mySubString,anotherString,this.maincontent).subscribe(res => {
    //   console.log(res);
    // });
    // this.getData();
    // this.service.generateEditor(this.editordata).subscribe(res => {
    //   console.log(res);
    // })
  }
}
