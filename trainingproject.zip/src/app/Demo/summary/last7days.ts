 
  export var lastdata = [
    {
      "name": "9:00",
      "series": [
        {
          "name": "Campaign 3",
          "value": 10
        },
        {
          "name": "Campaign 2",
          "value": 19
        }
      ]
    },

    {
      "name": "10:00",
      "series": [
        {
          "name": "Campaign 1",
          "value": 13
        },
        {
          "name": "Campaign 3",
          "value": 15
        }
      ]
    },

    {
      "name": "11:00",
      "series": [
        {
          "name": "Campaign 2",
          "value": 4
        },
        {
          "name": "Campaign 1",
          "value": 12
        }
      ]
    },

    {
      "name": "12:00",
      "series": [

        {
          "name": "Campaign 3",
          "value": 9
        }
      ]
    },

    {
      "name": "13:00",
      "series": [
        {
          "name": "Campaign 1",
          "value": 8
        },
        {
          "name": "Campaign 2",
          "value": 11
        }
      ]
    },
    {
      "name": "14:00",
      "series": [
        {
          "name": "Campaign 1",
          "value": 8
        },
        {
          "name": "Campaign 2",
          "value": 11
        }
      ]
    },
    {
      "name": "15:00",
      "series": [

      ]
    },
    {
      "name": "16:00",
      "series": [
        {
          "name": "Campaign 1",
          "value": 8
        },
        {
          "name": "Campaign 2",
          "value": 11
        }
      ]
    },

  ];
