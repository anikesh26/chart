import { Component, OnInit } from '@angular/core';
import {lastdata} from './last7days';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
  view: any[] = [800, 500];
  fullview: any[] = [1000, 500];

  // options for the chart
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = true;
  legendTitle = 'Campaign';
  showXAxisLabel = true;
  xAxisLabel = '';
  showYAxisLabel = true;
  yAxisLabel = '';
  timeline = true;

  colorScheme = {
    domain: ['#83d288', '#87CEFA', '#FA8072', '#FF7F50', '#90EE90', '#9370DB']
  };

  //pie
  showLabels = true;
  agentdata = lastdata;
  // data goes here
  multi = [
    {
      "name": "9:00",
      "series": [
        {
          "name": "Campaign 1",
          "value": 10,
          "stack": "hours"
        },
        {
          "name": "Campaign 2",
          "value": 19,
          "stack": "hours"
        },
        {
          "name": "Campaign 2",
          "linkedTo": "Campaign 2",
          "value": 13,
          "stack": "calls"
        },
      ]
    },

    {
      "name": "10:00",
      "series": [
        {
          "name": "Campaign 2",
          "value": 13,
          "stack": "calls"
        },
        {
          "name": "Campaign 3",
          "value": 15,
          "stack": "calls"
        }
      ]
    },

    {
      "name": "11:00",
      "series": [
        {
          "name": "Campaign 3",
          "value": 4
        },
        {
          "name": "Campaign 1",
          "value": 12
        }
      ]
    },

    {
      "name": "12:00",
      "series": [
        {
          "name": "Campaign 2",
          "value": 10
        },
        {
          "name": "Campaign 3",
          "value": 9
        }
      ]
    },

    {
      "name": "13:00",
      "series": [
        {
          "name": "Campaign 1",
          "value": 8
        },
        {
          "name": "Campaign 2",
          "value": 11
        }
      ]
    },
    {
      "name": "14:00",
      "series": [
        {
          "name": "Campaign 1",
          "value": 8
        },
        {
          "name": "Campaign 2",
          "value": 11
        }
      ]
    },
    {
      "name": "15:00",
      "series": [

      ]
    },
    {
      "name": "16:00",
      "series": [

      ]
    },

  ];
  initMulti: any;
  last7days: boolean = false;
  lastweek: boolean = false;

  onSelect($event) {
    console.log($event);
  }
  onResize(event) {
    this.view = [event.target.innerWidth / 1.5, 400];
    this.fullview = [event.target.innerWidth / 1.5, 400];

  }

  // onSelect(event) {
  //   if (this.isLegend(event)) {
  //     if (this.isDataShown(event)) {
  //       const tempData = JSON.parse(JSON.stringify(this.multi));
  //       tempData.forEach(country => {
  //         country.series.forEach(year => {
  //           if (year.name === event) {
  //             year.value = 0;
  //           }
  //         });
  //       });
  //       this.multi = tempData;
  //     } else {
  //       this.initMulti.forEach(country => {
  //         country.series.forEach(year => {
  //           if (year.name === event && year.value !== 0) {
  //             this.setChartDataBackToInitData(country.name, year.name, year.value)
  //           }
  //         });
  //       });
  //     }
  //   } else {
  //     console.log('emit event and do something else')
  //     // this.selection.emit(event);
  //   }
  // }

  isLegend = (event) => typeof event === 'string';

  // isDataShown = (event) => {
  //   const selectedBar = this.multi.find(model => {
  //     return model.series.find(singleModel => {
  //       return singleModel.name === event && singleModel.value !== 0;
  //     });
  //   });

  //   return typeof selectedBar !== 'undefined';
  // }

  setChartDataBackToInitData = (country, yearName, yearDefValue) => {
    const tempData = JSON.parse(JSON.stringify(this.multi));
    tempData.find(_country =>
      _country.name === country).series.find(_year => _year.name === yearName).value = yearDefValue;
    this.multi = tempData;
  }

  constructor() {
    this.initMulti = JSON.parse(JSON.stringify(this.multi));

  }
  ngOnInit(): void {

  }


  Last7Days() {
    this.last7days = true;
    this.lastweek = false;

    this.agentdata = [
      {
        "name": "9:00",
        "series": [
          {
            "name": "Campaign 3",
            "value": 5
          },
          {
            "name": "Campaign 2",
            "value": 7
          }
        ]
      },

      {
        "name": "10:00",
        "series": [
          {
            "name": "Campaign 1",
            "value": 13
          },
          {
            "name": "Campaign 3",
            "value": 15
          }
        ]
      },

      {
        "name": "11:00",
        "series": [
          {
            "name": "Campaign 2",
            "value": 4
          },
          {
            "name": "Campaign 1",
            "value": 12
          }
        ]
      },

      {
        "name": "12:00",
        "series": [

          {
            "name": "Campaign 3",
            "value": 9
          }
        ]
      },

      {
        "name": "13:00",
        "series": [
          {
            "name": "Campaign 1",
            "value": 8
          },
          {
            "name": "Campaign 2",
            "value": 11
          }
        ]
      },
      {
        "name": "14:00",
        "series": [
          {
            "name": "Campaign 1",
            "value": 8
          },
          {
            "name": "Campaign 2",
            "value": 11
          }
        ]
      },
      {
        "name": "15:00",
        "series": [

        ]
      },
      {
        "name": "16:00",
        "series": [
          {
            "name": "Campaign 1",
            "value": 8
          },
          {
            "name": "Campaign 2",
            "value": 11
          }
        ]
      },

    ];
  }

  lastWeek() {
    this.lastweek = true;
    this.last7days = false;

    this.agentdata = [
      {
        "name": "9:00",
        "series": [
          {
            "name": "Campaign 1",
            "value": 10
          },
          {
            "name": "Campaign 3",
            "value": 19
          }
        ]
      },

      {
        "name": "10:00",
        "series": [

          {
            "name": "Campaign 3",
            "value": 15
          }
        ]
      },

      {
        "name": "11:00",
        "series": [
          {
            "name": "Campaign 2",
            "value": 4
          },
          {
            "name": "Campaign 1",
            "value": 12
          }
        ]
      },

      {
        "name": "12:00",
        "series": [

          {
            "name": "Campaign 3",
            "value": 9
          }
        ]
      },

      {
        "name": "13:00",
        "series": [

          {
            "name": "Campaign 2",
            "value": 11
          }
        ]
      },
      {
        "name": "14:00",
        "series": [
          {
            "name": "Campaign 1",
            "value": 8
          },
          {
            "name": "Campaign 2",
            "value": 11
          }
        ]
      },
      {
        "name": "15:00",
        "series": [
          {
            "name": "Campaign 1",
            "value": 13
          },
        ]
      },
      {
        "name": "16:00",
        "series": [
          {
            "name": "Campaign 2",
            "value": 8
          },
          {
            "name": "Campaign 3",
            "value": 11
          }
        ]
      },

    ];
  }
}
