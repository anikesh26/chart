import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DemoComponent } from './Demo/demo/demo.component';
import { SummaryComponent } from './Demo/summary/summary.component';
import { LoginComponent } from './login/login.component';
import { NewchartComponent } from './newchart/newchart.component';
import { OtherchartComponent } from './otherchart/otherchart.component';
import { ProductdetailsComponent } from './products/productdetails/productdetails.component';
import { ProductlistComponent } from './products/productlist/productlist.component';



const routes: Routes = [
  { path: "", redirectTo: "summary", pathMatch: "full" },
  { path: 'welcome', component: DashboardComponent },
  { path: 'login', component: LoginComponent},

  { path: 'Productlist', component: ProductlistComponent},
  { path: 'Productdetails', component: ProductdetailsComponent},
  { path: 'demo', component: DemoComponent},
  { path: 'summary', component: SummaryComponent},
  { path: 'Otherchart', component: OtherchartComponent},
  { path: 'Newchart', component: NewchartComponent},






];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
