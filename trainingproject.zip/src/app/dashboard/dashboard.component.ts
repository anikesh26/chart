// import { FOCUS_TRAP_INERT_STRATEGY } from '@angular/cdk/a11y';
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ProductService } from '../products.service';
import { Fruits } from './fruits';
// import * as Editor from '@ckeditor/ckeditor5-angular';
import  ClassicEditor from '@ckeditor/ckeditor5-build-classic/build/ckeditor';
// import ClassicEditor from '@ckeditor/ckeditor5-editor-classic/src/classiceditor';
// import Mention from '@ckeditor/ckeditor5-mention/src/mention';



const COLORS: string[] = [
  'maroon',
  'red',
  'orange',
  'yellow',
  'olive',
  'green',
  'purple',
  'fuchsia',
  'lime',
  'teal',
  'aqua',
  'blue',
  'navy',
  'black',
  'gray',
];
const NAMES: string[] = [
  'Brinjal',
  'Cauliflower',
  'Okra',
  'Cucumber',
  'French Bean',
  'Guargum',
  'Radish',
  'Carrot',
  'Broccoli',
  'Snake Gourd',
  'Ridge Gourd',
  'Pointed Gourd (Parwal)',
  'Bitter Gourd (Kalara)',
  'Spiny Gourd (Kankada)',
  'Pumpkin (Kakharu)',
  'potato'
];
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit, AfterViewInit {
  allProducts: any;
  errorMessage: any;
  public Editor = ClassicEditor;
  msg="hello";
  constructor(private serviceproduct: ProductService) {}

  displayedColumns: string[] = ['id', 'name', 'progress', 'color'];
  dataSource: MatTableDataSource<Fruits>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  editorConfig = {
    toolbar: {
      items: [
        'bold',
        'italic',
        'underline',
        'link',
        'bulletedList',
        'numberedList',
        '|',
        'indent',
        'outdent',
        '|',
        'imageUpload',
        'blockQuote',
        'insertTable',
        'undo',
        'redo',
      ]
    },
    image: {
      toolbar: [
        'imageStyle:full',
        'imageStyle:side',
        '|',
        'imageTextAlternative'
      ]
    },
    table: {
      contentToolbar: [
        'tableColumn',
        'tableRow',
        'mergeTableCells'
      ]
    },
    // This value must be kept in sync with the language defined in webpack.config.js.
    language: 'en'
  }
  ngOnInit(): void {


  // this.Editor.create(document.getElementById( 'editor' ), {
  //     // This feature is not available in any of the builds.
  //     // See the "Installation" section.
  //     plugins: [ Mention],

  //     mention: {
  //         feeds: [
  //             {
  //                 marker: '@',
  //                 feed: [ '@Barney', '@Lily', '@Marshall', '@Robin', '@Ted' ],
  //                 minimumCharacters: 1
  //             }
  //         ]
  //     }
  // } )
  // .then( editor => {
  //   // ...
  // } )
  // .catch( error => {
  //   console.error( error );
  // } );






    // Create 100 users
    const users = Array.from({ length: 16 }, (_, k) =>
      this.createNewUser(k)
    );
    // this.createNewUser(1);

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource(users);


    // this.allProducts = this.serviceproduct.getProducts();
  //  this.serviceproduct.getProducts().subscribe( res => {
      // console.log(res);
      // console.log(this.allProducts);
    // });

    this.serviceproduct.getProducts().subscribe({
      next: products => {
        this.allProducts = products;
        // this.filteredProducts = this.products;
      },
      error: err => this.errorMessage = err
    });
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    console.log(event);
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  /** Builds and returns a new User. */
  createNewUser(id: number): Fruits {
    const name =
      NAMES
      [Math.round(Math.random() * (NAMES.length - 1))] +
      ' ' +
      NAMES[Math.round(Math.random() * (NAMES.length - 1))].charAt(0) +
      '.';

    return {
      id: id.toString(),
      name: name,
      progress: Math.round(Math.random() * 100).toString(),
      color: COLORS[Math.round(Math.random() * (COLORS.length - 1))],
    }
    ;
  }
}
