import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AllapiService {

  constructor(private http: HttpClient) { }

  generateEditor(editordata) {
    var body = {
      "name": editordata
    }
    return this.http.post('http://localhost:3000/editordata', body);
  }
  getEditorData() {
    return this.http.get('http://localhost:3000/editordata');
  }

  addEmpnames(mySubString,anotherString,maincontent) {
    var body = {
      "receivername":mySubString,
      "sendername": anotherString,
      "data":maincontent
    }
    return this.http.post('http://localhost:3000/empnames', body);
  }
  getEmpnames() {
    return this.http.get('http://localhost:3000/empnames');
  }
  getEmpdatabyId(id) {
    return this.http.get('http://localhost:3000/empnames/' + id);
    
  }
}
