declare var $: any;
$(function () {
    $('#container').highcharts({
       chart: {
          type: 'column'
       },
       plotOptions: {
          series: {
             grouping: false,
             stacking: 'normal',
             pointPadding: 0.2,
             allowPointSelect: true,
             states: {
                select: {
                   color: null,
                   borderWidth: 1,
                   borderColor: '#ffffff'
                }
             }
          }
       },
       title: {
          text: ''
       },
       xAxis: {
          categories: ['9:00', '10:00', '11:00'] //['Prius', 'Corolla', 'Civic', 'Accord']
       },
       yAxis: {
          min: 0,
          stackLabels: {
             style: {
                color: 'black'
             },
             enabled: false,
             formatter: function () {
                return this.stack;
             }
          }
       },
       legend: {
          legendTitle: 'Campaigns',
          layout: 'horizontal',
          align: 'left',
          verticalAlign: 'top',
          x: 800,
          y: 0,
          floating: true,
          borderWidth: 1,
       },
       credits: {
          enabled: false
       },

       series:
          [
             {
                name: 'Campaign 1',
                id: 'Campaign 1',
                stack: 'Hours',
                color: 'blue',
                data: [5],
                pointPlacement: -0.25,
                dataLabels: {
                   enabled: true,
                   inside: false,
                   formatter: function () {
                      return this.series.options.stack;
                   }
                }
             },
             {
                id: 'Campaign 2',
                name: 'Campaign 2',
                stack: 'Hours',
                color: 'black',
                data: [3],
                pointPlacement: -0.25
             },
             {
                id: 'Campaign 3',
                name: 'Campaign 3',
                stack: 'Hours',
                color: 'green',
                data: [3],
                pointPlacement: -0.25
             },
             {
                linkedTo: 'Campaign 1',
                stack: 'Email',
                color: 'blue',
                data: [5],
                pointPlacement: 0.20,
                dataLabels: {
                   enabled: true,
                   inside: false,
                   formatter: function () {
                      return this.series.options.stack;
                   }
                }
             },
             {
                linkedTo: 'Campaign 2',
                stack: 'Email',
                color: 'black',
                data: [3],
                pointPlacement: 0.20
             },
             {
                linkedTo: 'Campaign 3',
                stack: 'Email',
                color: 'green',
                data: [3],
                pointPlacement: 0.20
             },
             {
                linkedTo: 'Campaign 1',
                stack: 'Calls',
                color: 'blue',
                data: [[1, 5]],
                pointPlacement: -0.25,
                dataLabels: {
                   enabled: true,
                   inside: false,
                   formatter: function () {
                      return this.series.options.stack;
                   }
                }
             },
             {
                linkedTo: 'Campaign 2',
                stack: 'Calls',
                color: 'black',
                data: [[1, 3]],
                pointPlacement: -0.25
             },
             {
                linkedTo: 'Campaign 3',
                stack: 'Calls',
                color: 'green',
                data: [[1, 3]],
                pointPlacement: -0.25
             },
             {
                linkedTo: 'Campaign 3',
                stack: 'Email',
                color: 'green',
                data: [[1, 10]],
                pointPlacement: 0.20,
                dataLabels: {
                   enabled: true,
                   inside: false,
                   formatter: function () {
                      return this.series.options.stack;
                   }
                }

             },
             {
                linkedTo: 'Campaign 2',
                stack: 'Email',
                data: [[1, 5]],
                color: 'black',
                pointPlacement: 0.20
             },
             {
                linkedTo: 'Campaign 1',
                stack: 'Email',
                data: [[1, 5]],
                color: 'blue',
                pointPlacement: 0.20
             }
          ]
    });
 });


//  -----------------------------------------------------------------
