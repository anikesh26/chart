import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';

declare var $: any;

@Component({
   selector: 'app-otherchart',
   templateUrl: './otherchart.component.html',
   styleUrls: ['./otherchart.component.css']
})
export class OtherchartComponent implements OnInit {
   callclick: boolean = false;
   series=
      [
         {
            name: 'Campaign 1',
            id: 'Campaign 1',
            data: [5, 3, 4, 7, 2, 6, 8],
            stack: 'hours',
            color: 'blue',
            dataLabels: {
               enabled: true,
               inside: false,
               formatter: function () {
                  return this.series.options.stack;
               }
            }
         },
         {
            name: 'Campaign 2',
            id: 'Campaign 2',
            data: [2, 5, 6, 2, 1],
            stack: 'hours',
            color:'red'
         },
         {
            linkedTo: 'Campaign 3',
            data: [1, 3, 8, 7, 2],
            stack: 'hours',
            color:'green'
         },
         {
            linkedTo: 'Campaign 1',
            data: [3, 4, 4, 2, 5],
            stack: 'emails',
            color: 'blue',
            dataLabels: {
               enabled: true,
               inside: false,
               formatter: function () {
                  return this.series.options.stack;
               }
            }
         },
         {
            linkedTo: 'Campaign 2',
            data: [2, 5, 6, 2, 1],
            stack: 'emails',
            color:'red'
         },
         {
            name: 'Campaign 3',
            id: 'Campaign 3',
            data: [2, 5, 6, 2, 1],
            stack: 'calls',
            color: 'green',
            dataLabels: {
               enabled: true,
               inside: false,
               formatter: function () {
                  return this.series.options.stack;
               }
            }
         },
        
         {
            linkedTo: 'Campaign 3',
            data: [2, 5, 6, 2, 1],
            stack: 'Unique Calls',
            color: 'green',
            dataLabels: {
               enabled: true,
               inside: false,
               formatter: function () {
                  return this.series.options.stack;
               }
            }
         },
         {
            linkedTo: 'Campaign 2',
            data: [2, 5, 6, 2, 1],
            stack: 'Unique Calls',
            color:'red'
         },
         {
            linkedTo: 'Campaign 3',
            data: [2, 3, 8,],
            stack: 'Pipelines',
            color: 'green',
            dataLabels: {
               enabled: true,
               inside: false,
               formatter: function () {
                  return this.series.options.stack;
               }
            }
         },
         {
            linkedTo: 'Campaign 2',
            data: [2, 0, 6, 3, 5],
            stack: 'Pipelines',
            color:'red'
         },
         {
            linkedTo: 'Campaign 1',
            data: [2, 3, 8,],
            stack: 'Lead Volumes',
            color: 'blue',
            dataLabels: {
               enabled: true,
               inside: false,
               formatter: function () {
                  return this.series.options.stack;
               }
            }
         },
         {
            linkedTo: 'Campaign 3',
            data: [2, 0, 5],
            stack: 'Lead Volumes',
            color:'green'
         },
         {
            linkedTo: 'Campaign 2',
            data: [2, 3, 8,],
            stack: 'Conversions',
            color: 'red',
            dataLabels: {
               enabled: true,
               inside: false,
               formatter: function () {
                  return this.series.options.stack;
               }
            }
         },
         {
            linkedTo: 'Campaign 3',
            data: [2, 0, 5],
            stack: 'Conversions',
            color:'green'
         },
      ];
   chartOptions ;
   constructor() {
      
    }

   isChecked: boolean = false;
   isemailChecked: boolean = false;
   highcharts = Highcharts;



getChartData(series:any){
   // this.chartOptions.update()
this.chartOptions={
   chart: {
      type: 'column'
   },
   title: {
      text: ''
   },
   xAxis: {
      categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
   },
   yAxis: {
      allowDecimals: false,
      min: 0,
      title: {
         text: ''
      }
   },
   plotOptions: {
      column: {
         stacking: 'normal'
      }
   },
   credits: {
      enabled: false
   },
   legend: {
      legendTitle: 'Campaigns',
      layout: 'vertical',
      align: 'left',
      verticalAlign: 'top',
      x: 670,
      y: 0,
      floating: true,
      borderWidth: 1,
      backgroundColor: ((Highcharts.theme && Highcharts.theme.colors) || '#FFFFFF'),
      shadow: true
   },

   series
};
}






   ngOnInit(): void {
      this.getChartData(this.series);
   }

   changeGraph() {
      if (this.isChecked === true) {
           console.log('if');
         const series = [
            {
               name: 'Campaign 1',
               id: 'Campaign 1',
               data: [5, 3, 4, 7, 2],
               stack: 'hours',
               color: 'blue',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
            {
               name: 'Campaign 2',
               id: 'Campaign 2',
               data: [2, 5, 6, 2, 1],
               stack: 'hours',
               color:'red'
            },
            {
               name: 'Campaign 3',
               id: 'Campaign 3',
               data: [1, 3, 8, 7, 2],
               stack: 'hours',
               color:'green'
            },
         ];
         this.getChartData(series);

      }

      else {
         console.log('else');

         const series = [
            {
               name: 'Campaign 1',
               id: 'Campaign 1',
               data: [5, 3, 4, 7, 2, 6, 8],
               stack: 'hours',
               color: 'blue',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
            {
               name: 'Campaign 2',
               id: 'Campaign 2',
               data: [2, 5, 6, 2, 1],
               stack: 'hours',
               color:'red'
            },
            {
               name: 'Campaign 3',
               id: 'Campaign 3',
               data: [1, 3, 8, 7, 2],
               stack: 'hours',
               color:'green'
            },
            {
               linkedTo: 'Campaign 1',
               data: [3, 4, 4, 2, 5],
               stack: 'emails',
               color: 'blue',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
            {
               linkedTo: 'Campaign 2',
               data: [2, 5, 6, 2, 1],
               stack: 'emails',
               color:'red'
            },
            {
               linkedTo:'Campaign 3',
               data: [2, 5, 6, 2, 1],
               stack: 'calls',
               color: 'green',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
   
            {
               linkedTo: 'Campaign 3',
               data: [2, 5, 6, 2, 1],
               stack: 'Unique Calls',
               color: 'green',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
            {
               linkedTo: 'Campaign 2',
               data: [2, 5, 6, 2, 1],
               stack: 'Unique Calls',
               color:'red'
            },
            {
               linkedTo: 'Campaign 3',
               data: [2, 3, 8,],
               stack: 'Pipelines',
               color: 'green',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
            {
               linkedTo: 'Campaign 2',
               data: [2, 0, 6, 3, 5],
               stack: 'Pipelines',
               color:'red'
            },
            {
               linkedTo: 'Campaign 1',
               data: [2, 3, 8,],
               stack: 'Lead Volumes',
               color: 'blue',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
            {
               linkedTo: 'Campaign 3',
               data: [2, 0, 5],
               stack: 'Lead Volumes',
               color:'green'
            },
            {
               linkedTo: 'Campaign 2',
               data: [2, 3, 8,],
               stack: 'Conversions',
               color: 'red',
               dataLabels: {
                  enabled: true,
                  inside: false,
                  formatter: function () {
                     return this.series.options.stack;
                  }
               }
            },
            {
               linkedTo: 'Campaign 3',
               data: [2, 0, 5],
               stack: 'Lead Volumes',
               color:'green'
            },
         ];
         this.series=[];
         this.getChartData(series);

      }
   }

   onHourClick() {
        console.log(this.isChecked);
      this.isChecked = !this.isChecked;
      // this.isemailChecked = false;
      // this.callclick = false;
      this.changeGraph();

   }


   changeEmailGraph() {
      //   console.log(this.isChecked);
      if (this.isemailChecked === true) {
         this.isChecked = false;
         this.callclick = false;
         // this.chartOptions = {
         //    chart: {
         //       type: 'column'
         //    },
         //    title: {
         //       text: ''
         //    },
         //    xAxis: {
         //       categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
         //    },
         //    yAxis: {
         //       allowDecimals: false,
         //       min: 0,
         //       title: {
         //          text: ''
         //       }
         //    },
         //    plotOptions: {
         //       column: {
         //          stacking: 'normal'
         //       }
         //    },
         //    credits: {
         //       enabled: false
         //    },
         //    legend: {
         //       legendTitle: 'Campaigns',
         //       layout: 'vertical',
         //       align: 'left',
         //       verticalAlign: 'top',
         //       x: 670,
         //       y: 0,
         //       floating: true,
         //       borderWidth: 1,
         //       backgroundColor: ((Highcharts.theme && Highcharts.theme.colors) || '#FFFFFF'),
         //       shadow: true
         //    },
         //    // colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'],
         //    series: [
         //       {
         //          name: 'Campaign 1',
         //          data: [4, 0, 6],
         //          stack: 'male',

         //       },
         //       {
         //          name: 'Campaign 2',
         //          data: [5, 5],
         //          stack: 'male'
         //       },
         //       {
         //          name: 'Campaign 3',
         //          data: [3, 7],
         //          stack: 'male'
         //       },
         //    ]
         // };

      }
      else {

         // this.chartOptions = {
         //    chart: {
         //       type: 'column'
         //    },
         //    title: {
         //       text: ''
         //    },
         //    xAxis: {
         //       categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
         //    },
         //    yAxis: {
         //       allowDecimals: false,
         //       min: 0,
         //       title: {
         //          text: ''
         //       }
         //    },
         //    plotOptions: {
         //       column: {
         //          stacking: 'normal'
         //       }
         //    },
         //    credits: {
         //       enabled: false
         //    },
         //    legend: {
         //       legendTitle: 'Campaigns',
         //       layout: 'vertical',
         //       align: 'left',
         //       verticalAlign: 'top',
         //       x: 670,
         //       y: 0,
         //       floating: true,
         //       borderWidth: 1,
         //       backgroundColor: ((Highcharts.theme && Highcharts.theme.colors) || '#FFFFFF'),
         //       shadow: true
         //    },
         //    // colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'],
         //    series: [
         //       {
         //          name: 'Campaign 1',
         //          data: [2],
         //          stack: 'male',
         //       },
         //       {
         //          name: 'Campaign 2',
         //          data: [2],
         //          stack: 'male'
         //       },
         //       {
         //          name: 'Campaign 3',
         //          data: [1],
         //          stack: 'male'
         //       },
         //    ]
         // };
      }
   }
   onEmailClick() {
      //   console.log('hii');
      this.isemailChecked = true;
      this.changeEmailGraph();

   }


   changeCallGraph() {
      //   console.log(this.isChecked);
      if (this.callclick === true) {
         this.isemailChecked = false;
         this.isChecked = false;

         // this.chartOptions = {
         //    chart: {
         //       type: 'column'
         //    },
         //    title: {
         //       text: ''
         //    },
         //    xAxis: {
         //       categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
         //    },
         //    yAxis: {
         //       allowDecimals: false,
         //       min: 0,
         //       title: {
         //          text: ''
         //       }
         //    },
         //    plotOptions: {
         //       column: {
         //          stacking: 'normal'
         //       }
         //    },
         //    credits: {
         //       enabled: false
         //    },
         //    legend: {
         //       legendTitle: 'Campaigns',
         //       layout: 'vertical',
         //       align: 'left',
         //       verticalAlign: 'top',
         //       x: 670,
         //       y: 0,
         //       floating: true,
         //       borderWidth: 1,
         //       backgroundColor: ((Highcharts.theme && Highcharts.theme.colors) || '#FFFFFF'),
         //       shadow: true
         //    },
         //    // colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'],
         //    series: [
         //       {
         //          name: 'Campaign 1',
         //          data: [1, 0, 0, 5],
         //          stack: 'male',

         //       },
         //       {
         //          name: 'Campaign 2',
         //          data: [2, 0, 3],
         //          stack: 'male'
         //       },
         //       {
         //          name: 'Campaign 3',
         //          data: [0, 5],
         //          stack: 'male'
         //       },
         //    ]
         // };

      }
      else {

         // this.chartOptions = {
         //    chart: {
         //       type: 'column'
         //    },
         //    title: {
         //       text: ''
         //    },
         //    xAxis: {
         //       categories: ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00']
         //    },
         //    yAxis: {
         //       allowDecimals: false,
         //       min: 0,
         //       title: {
         //          text: ''
         //       }
         //    },
         //    plotOptions: {
         //       column: {
         //          stacking: 'normal'
         //       }
         //    },
         //    credits: {
         //       enabled: false
         //    },
         //    legend: {
         //       legendTitle: 'Campaigns',
         //       layout: 'vertical',
         //       align: 'left',
         //       verticalAlign: 'top',
         //       x: 670,
         //       y: 0,
         //       floating: true,
         //       borderWidth: 1,
         //       backgroundColor: ((Highcharts.theme && Highcharts.theme.colors) || '#FFFFFF'),
         //       shadow: true
         //    },
         //    // colors: ['#058DC7', '#50B432', '#ED561B', '#DDDF00', '#24CBE5', '#64E572', '#FF9655', '#FFF263', '#6AF9C4'],
         //    series: [
         //       {
         //          name: 'Campaign 1',
         //          data: [5, 3, 4, 7, 2, 6, 8],
         //          stack: 'male',
         //       },
         //       {
         //          name: 'Campaign 2',
         //          data: [3, 4, 4, 2, 5],
         //          stack: 'male'
         //       },
         //       {
         //          name: 'Campaign 3',
         //          data: [2, 5, 6, 2, 1],
         //          stack: 'male'
         //       },
         //    ]
         // };
      }
   }
   onCallClick() {
      this.callclick = !this.callclick;
      this.changeCallGraph();
   }
}
