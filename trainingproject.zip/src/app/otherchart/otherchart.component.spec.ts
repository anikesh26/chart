import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherchartComponent } from './otherchart.component';

describe('OtherchartComponent', () => {
  let component: OtherchartComponent;
  let fixture: ComponentFixture<OtherchartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherchartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherchartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
