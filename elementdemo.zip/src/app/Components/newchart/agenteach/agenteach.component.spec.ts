import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgenteachComponent } from './agenteach.component';

describe('AgenteachComponent', () => {
  let component: AgenteachComponent;
  let fixture: ComponentFixture<AgenteachComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgenteachComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgenteachComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
