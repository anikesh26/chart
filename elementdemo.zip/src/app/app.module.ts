import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewchartComponent } from './Components/newchart/newchart.component';
import { CampaignComponent } from './Components/newchart/campaign/campaign.component';
import { AgenteachComponent } from './Components/newchart/agenteach/agenteach.component';
import { AgentindividualComponent } from './Components/newchart/agentindividual/agentindividual.component';

@NgModule({
  declarations: [
    AppComponent,
    NewchartComponent,
    CampaignComponent,
    AgenteachComponent,
    AgentindividualComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxChartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
