import { TestBed } from '@angular/core/testing';

import { NewchartService } from './newchart.service';

describe('NewchartService', () => {
  let service: NewchartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewchartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
