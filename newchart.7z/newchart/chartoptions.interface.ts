export interface chartOptions {
    chart: {
        type: string;
    }
    title:
    {
        text:string;
    } 
    xAxis: {
        categories:string[];
    }
    yAxis: {
        min: number;
        title: { text: string};
    };
    legend:
    {
        reversed: boolean;
    };
    plotOptions:
    {
        series:
        {
            stacking: string;
        };
    };
    series: any;
}
